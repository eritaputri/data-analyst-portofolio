import pandas as pd

def clean_sales_data(df):
    df = df.copy()

    # Duplicat deleted
    df = df.drop_duplicates()

    # Delete empty data
    df = df.dropna(subset=['order_date', 'quantity', 'total_amount'])

    # Convert data type
    if 'order_date' in df.columns:
        df['order_date'] = pd.to_datetime(df['order_date'], errors='coerce')
    if 'join_date' in df.columns:
        df['join_date'] = pd.to_datetime(df['join_date'], errors='coerce')
    if 'quantity' in df.columns:
        df['quantity'] = pd.to_numeric(df['quantity'], errors='coerce')
    if 'total_amount' in df.columns:
        df['total_amount'] = pd.to_numeric(df['total_amount'], errors='coerce')

    # Text Format Standardization
    if 'customer_name' in df.columns:
        df['customer_name'] = df['customer_name'].astype(str).str.strip().str.title()
    if 'region' in df.columns:
        df['region'] = df['region'].astype(str).str.strip().str.title()
    if 'product_name' in df.columns:
        df['product_name'] = df['product_name'].astype(str).str.strip().str.title()
    if 'category' in df.columns:
        df['category'] = df['category'].astype(str).str.strip().str.title()
    
    # Delete rows whose sum/value is negative
    df = df[df['quantity'] > 0]
    df = df[df['total_amount'] > 0]

    # Add Column
    if 'order_date' in df.columns:
        df['week'] = df['order_date'].dt.isocalendar().week.astype(str)
    if 'order_date' in df.columns:
        df['month'] = df['order_date'].dt.to_period('M').astype(str)
    if 'order_date' in df.columns:
        df['year'] = df['order_date'].dt.to_period('Y').astype(str)
    # Reset Index
    df = df.reset_index(drop=True)
    return df

def format_rupiah(x):
    return f"Rp{x:,.0f}".replace(",", ".")