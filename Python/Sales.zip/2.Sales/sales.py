# Required Libraries Installation
# pip install mysql-connector-python sqlalchemy pandas
# pip install tabulate
# pip install streamlit
# pip install plotly
# Run app with: streamlit run sales.py


# Load library & dataset
import streamlit as st # Build interactive web app
from tabulate import tabulate # Display tables in console
import pandas as pd # Data processing
from sqlalchemy import create_engine # MySQL connection
from data_utils import clean_sales_data, format_rupiah # Data cleaning and formatting
import plotly.express as px # Data visualization

# Connection to mysql database
db_connection_str = create_engine("mysql+mysqlconnector://root:@localhost/sales_db")

#SQL Query
query = """
SELECT 
orders.order_id, orders.order_date, 
customers.customer_id, customers.name AS customer_name, customers.region, customers.join_date,
products.product_id, products.product_name, products.category,
orders.quantity, orders.total_amount
FROM orders 
JOIN customers ON orders.customer_id = customers.customer_id
JOIN products ON orders.product_id = products.product_id;
"""
# Load data
sales_data = pd.read_sql(query, db_connection_str) # Read dataset from SQL

# Exploratory Data
print(tabulate(sales_data.head(5), headers='keys', tablefmt='grid', showindex=False)) # Displays the first 5 rows of the dataset in a neatly formatted table
print(sales_data.info()) # Shows a summary of the dataset
print(sales_data.isnull().sum()) # Checks how many missing (null) values
print(sales_data.duplicated().sum()) # Counts the number of duplicate rows
print(sales_data['region'].unique()) # Displays all unique values in the region column
print(sales_data['category'].unique()) # Displays all unique values in the category column

# Cleaning Data
sales_data = clean_sales_data(sales_data) # Calls the clean_sales_data() function from data_utils.py
print(tabulate(sales_data.head(5), headers='keys', tablefmt='grid', showindex=False))

# Sidebar filter dropdown
st.sidebar.header('Filter Data')
# Dropdown to select year
year_filter = st.sidebar.multiselect(
    "Select Year", 
    options = sales_data['year'].unique(), 
    default = sales_data['year'].unique())
filtered_data = sales_data[sales_data['year'].isin(year_filter)] # Filter dataset based on selected year

# KPI Section
# Calculate key performance indicators
st.title("Sales Dashboard")
total_sales = filtered_data['total_amount'].sum()
total_orders = filtered_data['order_id'].nunique()
total_customers = filtered_data['customer_id'].nunique()
aov = round(filtered_data['total_amount'].mean(),2)
# Display KPI metrics in four columns
col1, col2, col3, col4 = st.columns(4)
col1.metric("Total Sales", format_rupiah(total_sales))
col2.metric("Total Orders", total_orders)
col3.metric("Total Customers", total_customers)
col4.metric("Avg Order Value", format_rupiah(aov))

# Visualizations
st.header("Trends & Insights")
# 1. Total sales by Year
sales_by_year = filtered_data.groupby('year')['total_amount'].sum().reset_index()
fig1 = px.bar(sales_by_year, x='year', y='total_amount', text='total_amount', title="Total Sales by Year")
fig1.update_xaxes(type="category")
st.plotly_chart(fig1, use_container_width=True)

# 2. Top 5 Products
top_products = filtered_data.groupby('product_name')['total_amount'].sum().sort_values(ascending=False).head(5).reset_index()
fig2 = px.bar(top_products, x='product_name', y='total_amount', color='product_name', title="Top 5 Products")
st.plotly_chart(fig2, use_container_width=True)

# 3. Sales by Category
sales_by_category = filtered_data.groupby(['year','category'])['total_amount'].sum().reset_index()
fig3 = px.line(sales_by_category, x='year', y='total_amount', color='category', markers=True, title="Sales by Category per Year")
fig3.update_xaxes(type="category")
st.plotly_chart(fig3, use_container_width=True)

# 4. Sales by Region
sales_by_region = filtered_data.groupby(['year','region'])['total_amount'].sum().reset_index()
fig4 = px.bar(sales_by_region, x='region', y='total_amount', color='year', barmode='group', title="Sales by region per Year")
st.plotly_chart(fig4, use_container_width=True)

# Raw Data View
with st.expander(" View Raw Data"):
    st.dataframe(filtered_data)

st.caption("© 2025 - Streamlit Dashboard by Erita Putri Ramadhani")